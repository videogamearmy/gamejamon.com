<?php
/* --------------------------------------------------------------------------

	Plugin Name: Boost Maha
	Plugin URI: http://www.thememaha.com
	Description: ThemeMaha Boost.
	Version: 1.1
	Author: ThemeMaha
	Author URI: http://www.thememaha.com

	A ThemeMaha Framework - Copyright (c) 2014
	Please be extremely cautions editing this file!

 ---------------------------------------------------------------------------*/

class Boost_Maha {

	var $style = '';
	var $styles_for_footer = array();
	var $styles_for_wp_style = array();
	var $styles_no_minify = array();
	var $script_for_footer = array();
	var $jquery_to_footer = array();
	
	public function __construct() {
		define('Boost_Maha' , 'v1.1');

		$this->options = $this->getOptions();
		register_deactivation_hook( __FILE__, array('Boost_Maha', 'boostMahaDeactive') );
		register_activation_hook( __FILE__, array('Boost_Maha', 'boostMahaActive') );

		if(is_admin()){
			$this->admin();
		} else {
			add_action('wp_enqueue_scripts', array($this, 'maha_resource'), 100);
			add_action('wp_footer', array($this, 'maha_register_no_minify'), 1);
			add_action('wp_footer', array($this, 'maha_register_wp_style'), 2);
			add_action('wp_footer', array($this, 'maha_register_footer'), 3);
			add_action('wp_enqueue_scripts', array($this, 'maha_register_script_footer'), 100);
			add_action('wp_head', array($this, 'maha_visibility'));
			add_action('get_header', array($this, 'maha_html_compression_start'));
			add_filter('clean_url', array($this, 'maha_js_defer_plugin'), 11, 1);
		}
	}

	private function admin(){
		include_once('inc/admin.php');
		$maha = new boost_maha_admin();
		$maha->addMenuPage();
	}

	function maha_visibility() {
        echo '<style>body{visibility:hidden;}</style>';
    }

	function maha_resource(){
		global $wp_styles, $wp_scripts;

		$this->maha_deregister_style('dashicons', 2);
        $this->maha_deregister_style('admin-bar', 2);

		$maha_registered_css_nonminify = array(
			'open-sans',
			'maha_heading_font',
			'maha_main_font',
			'maha_content_font'
		);

		foreach ($wp_styles->queue as $key => $value) {
			if ( in_array($value, $maha_registered_css_nonminify ) ) {
				$this->maha_deregister_style($value, 1);
			}
		}

		$maha_registered_css = array(
			'maha-woo',
			'maha-basix',
			'maha-entypo',
			'maha-bootstrap',
			'maha-shortcodes-o',
			'maha-basix-r',
			'login-with-ajax',
			'bp-parent-css',
			'bp-legacy-css',
			'contact-form-7',
			'bbp-default-bbpress',
			'bbp-default'
		);

		foreach ($wp_styles->queue as $key => $value) {
			if ( in_array($value, $maha_registered_css ) ) {
				$this->maha_deregister_style($value, 0);
			}
		}

		$maha_registered_js = array(
			'login-with-ajax',
			'admin-bar',
			'bbpress-editor',
			'bp-parent-js',
			'bp-confirm',
			'wc-add-to-cart',
			'woocommerce',
			'wc-cart-fragments',
			'maha-basix',
			'maha-main',
			'add_to_cart',
			'comment-reply'
		);

		foreach ($wp_scripts->queue as $key => $value) {
			if ( in_array($value, $maha_registered_js ) ) {
				$this->maha_deregister_script($value);
			}
		}
	}

	function maha_deregister_style( $style, $code ){
		global $wp_styles;

		if (!empty($wp_styles->registered[$style]) and !empty($wp_styles->registered[$style]->src)) {
			
			switch ( $code ) {
				case '0':
					$this->styles_for_footer[$style] = $wp_styles->registered[$style]->src;
					break;

				case '1':
					$this->styles_no_minify[$style] = $wp_styles->registered[$style]->src;
					break;

				case '2':
					$this->styles_for_wp_style[$style] = $wp_styles->registered[$style]->src;
					break;
				
				default:
					
					break;
			}
            
            wp_deregister_style($style);
        }
	}

	function maha_register_wp_style(){
		$http = "http://";
		if (!empty($_SERVER['HTTPS'])) {
		    $http = "https://";
		}
		$replace = $http.$_SERVER['HTTP_HOST'].'/';
		if ( !is_multisite() ) {
			$getUrl = get_site_url().'/';
		} else {
			$getUrl = network_site_url();
		}
		$getUrl = str_replace( $replace, '', $getUrl);

		foreach ($this->styles_for_wp_style as $style_id => $style_src) {
			if( isset($this->options->boostMahaMinify) ){
				$style_src = $http.$_SERVER['HTTP_HOST'].$style_src;
       			$style_src = str_replace( $replace, "", $style_src );
       			$pluginUrl = plugins_url('boost-maha/min/f=');
        		$style_src = $pluginUrl.$getUrl.$style_src;
       			wp_enqueue_style( $style_id, $style_src );
			}
		}
	}

	function maha_register_no_minify(){
		foreach ($this->styles_no_minify as $style_id => $style_src) {
			wp_enqueue_style( $style_id, $style_src );
		}
	}

	function maha_register_footer(){
		$http = "http://";
		if (!empty($_SERVER['HTTPS'])) {
		    $http = "https://";
		}
		$replace = $http.$_SERVER['HTTP_HOST'].'/';
		$pluginUrl = plugins_url('boost-maha/min/f=');

		if ( !is_multisite() ) {
			$getUrl = get_site_url().'/';
		} else {
			$getUrl = network_site_url();
		}

		foreach ($this->styles_for_footer as $style_id => $style_src) {
			if( isset($this->options->boostMahaMinify) ){
       			$style_src = str_replace( get_site_url().'/', $getUrl, $style_src );
       			$style_src = str_replace( $replace, '', $style_src );
        		$style_src = $pluginUrl.$style_src;
        		wp_enqueue_style( $style_id, $style_src );
        	}
        }
	}

	function maha_deregister_script( $script ){
		global $wp_scripts;

		if (!empty($wp_scripts->registered[$script]) and !empty($wp_scripts->registered[$script]->src)) {
            	$this->script_for_footer[$script] = $wp_scripts->registered[$script]->src;
            	wp_deregister_script($script);
        }
	}

	function maha_register_script_footer(){
		$http = "http:";
       		if (!empty($_SERVER['HTTPS'])) {
			$http = "https:";
		}
		$replace = '//'.$_SERVER['HTTP_HOST'].'/';
		$url = str_replace( $http, "" ,get_site_url() );
		$pluginUrl = plugins_url('boost-maha/min/f=');

		foreach ($this->script_for_footer as $script_id => $script_src) {
			if ( !is_multisite() ) {
				$site_url = get_site_url();
			} else {
				$site_url = network_site_url();
			}

			if( isset($this->options->boostMahaMinify) ){
				$script_src = str_replace( $url, "", $script_src );
				$script_src = $site_url.$script_src;
				$script_src = str_replace( $site_url.'/', "", $script_src );
				$script_src = str_replace( $site_url.$http.'/', "", $script_src );
				if ( !is_multisite() ) { $site_url .= '/'; }
				$script_src = $site_url.$script_src;
				$script_src = str_replace( $http.$replace, "", $script_src );
        		$script_src = $pluginUrl.$script_src;
				wp_enqueue_script( $script_id, $script_src, 'jquery', '1.0.0', true );        		
	        }
        }
        wp_localize_script( 'maha-basix', 'MahaAjax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );
	}

	function maha_html_compression_finish($html){
		if ( isset( $this->options->boostMahaMinifyHtml ) ) {
			require_once("inc/boost-html.php");
			return new WP_HTML_Compression($html);
		}
	}

	function maha_html_compression_start(){
		if ( isset( $this->options->boostMahaMinifyHtml ) ) {
			ob_start(array($this, 'maha_html_compression_finish'));
		}
	}

	function maha_js_defer_plugin( $url ){
	    if ( !is_admin() ) {
	        if ( TRUE == strpos( $url, 'login-with-ajax.js' ) || TRUE == strpos( $url, 'admin-bar.min.js' ) || TRUE == strpos( $url, 'jquery-migrate.min.js' ) || TRUE == strpos( $url, 'editor.js' ) || TRUE == strpos( $url, 'buddypress.js' ) || TRUE == strpos( $url, 'comment-reply.min.js' ) || TRUE == strpos( $url, 'confirm.min.js' ) || TRUE == strpos( $url, 'jquery-form.min.js' ) || TRUE == strpos( $url, 'scripts.js' ) || TRUE == strpos( $url, 'add-to-cart.min.js' ) || TRUE == strpos( $url, 'woocommerce.min.js' ) || TRUE == strpos( $url, 'cart-fragments.min.js' ) || TRUE == strpos( $url, 'basix.js' ) || TRUE == strpos( $url, 'add_to_cart.js' ) )
	        {
	            return "$url' defer='defer";
	        } else{
	            return $url;
	        }
	    } else {
	        return $url;
	    }
	}

	protected function getOptions(){
		if($data = get_option("BoostMaha")){
			return json_decode($data);
		}
	}

	public function boostMahaDeactive(){
		$htaccess_file = ABSPATH.'.htaccess';
		if(is_file( $htaccess_file ) && is_writable( $htaccess_file )){
			$htaccess = file_get_contents( $htaccess_file );
			$htaccess = preg_replace("/#\s?BEGIN\s?boostMahaGzip.*?#\s?END\s?boostMahaGzip/s", "", $htaccess);
			$htaccess = preg_replace("/#\s?BEGIN\s?boostMahaLBC.*?#\s?END\s?boostMahaLBC/s", "", $htaccess);
			file_put_contents( $htaccess_file, $htaccess );
		}
	}

	function boostMahaActive(){
		include_once('inc/admin.php');
		$maha = new boost_maha_admin();

		if($data = get_option("BoostMaha")){
			$data = json_decode($data);

			if ( isset( $data->boostMahaGzip ) && !empty( $data->boostMahaGzip ) ) {
				$maha->insertToHtaccess( 'boostMahaGzip' );
			}
			if ( isset( $data->boostMahaLBC ) && !empty( $data->boostMahaLBC ) ) {
				$maha->insertToHtaccess( 'boostMahaLBC' );
			}
		}
	}
	
}
$Boost_Maha = new Boost_Maha;