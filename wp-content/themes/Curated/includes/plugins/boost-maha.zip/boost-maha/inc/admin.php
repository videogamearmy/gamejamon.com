<?php
	class boost_maha_admin extends Boost_Maha {
		private $menuTitle = "Boost Maha";
		private $pageTitle = "Boost Maha Settings";
		private $options = array();

		public function __construct(){
			$this->options = $this->getOptions();
			
			$this->optionsPageRequest();
			// $this->iconUrl = plugins_url("boost-maha/img/maha.svg");
			$this->iconUrl = '';
		}

		public function addMenuPage(){
			add_action('admin_menu', array($this, 'register_boost_maha_menu'));
		}

		public function register_boost_maha_menu(){
			if(function_exists('add_menu_page')){ 
				add_menu_page($this->pageTitle, $this->menuTitle, 'manage_options', "BoostMahaOptions", array($this, 'options'), $this->iconUrl, 99 );
				wp_enqueue_style("boost-maha-style", plugins_url("boost-maha/css/boost-maha.css"), array(), time(), "all");
			}
		}

		public function optionsPageRequest(){
			if(!empty($_POST)){
				if(isset($_POST["boostMahaPage"])){
					if($_POST["boostMahaPage"] == "options"){
						$this->saveOption();
					}
				}
				if(isset($_POST["removecache"])){
					if($_POST["removecache"] == 1){
						$this->saveOption();
					}
				}
			}
		}

		public function saveOption(){
			if ( isset($_POST["boostMahaPage"]) ) {
				unset($_POST["boostMahaPage"]);
				$data = json_encode($_POST);
				$this->options = json_decode($data);

				$this->htaccess($_POST);

				if(get_option("BoostMaha")){
					update_option("BoostMaha", $data);
				}else{
					add_option("BoostMaha", $data, null, "yes");
				}
			}
			if ( isset($_POST['removecache']) ) {
				$files = glob(ABSPATH.'wp-content/plugins/boost-maha/cache/*'); // get all file names
				foreach($files as $file){ // iterate files
				  if(is_file($file)){
				  	$pathPart = explode(".",$file);
				  	$fileEx = $pathPart[count($pathPart)-1];
				  	if($fileEx != "html" && $fileEx != "htm"){
       					unlink($file);
    				}	
				  }
				}
			}
		}

		public function options(){
			$boostMahaGzip = isset($this->options->boostMahaGzip) ? 'checked="checked"' : "";
			$boostMahaLBC = isset($this->options->boostMahaLBC) ? 'checked="checked"' : "";
			$boostMahaMinify = isset($this->options->boostMahaMinify) ? 'checked="checked"' : "";
			$boostMahaMinifyHtml = isset($this->options->boostMahaMinifyHtml) ? 'checked="checked"' : "";
		?>
			<div class="wrap">
				<h2>Boost Maha Options</h2>

				<form method="post" name="boostMahaForm">
					<input type="hidden" value="options" name="boostMahaPage">
					<div class="boostMahaGroup">
						<div class="boostMahaText">Gzip</div>
						<div class="boostMahaInput"><input type="checkbox" <?php echo $boostMahaGzip; ?> id="boostMahaGzip" name="boostMahaGzip">
							<label for="boostMahaGzip">Enable/Disable gzip compression.</label>
						</div>
					</div>
					<div class="boostMahaGroup">
						<div class="boostMahaText">Leverage Browser Caching</div>
						<div class="boostMahaInput"><input type="checkbox" <?php echo $boostMahaLBC; ?> id="boostMahaLBC" name="boostMahaLBC">
							<label for="boostMahaLBC">Enable/Disable leverage browser caching.</label>
						</div>
					</div>
					<div class="boostMahaGroup">
						<div class="boostMahaText">Minify CSS & JS</div>
						<div class="boostMahaInput"><input type="checkbox" <?php echo $boostMahaMinify; ?> id="boostMahaMinify" name="boostMahaMinify">
							<label for="boostMahaMinify">Enable/Disable minify css & js.</label>
						</div>
					</div>
					<div class="boostMahaGroup">
						<div class="boostMahaText">Minify HTML</div>
						<div class="boostMahaInput"><input type="checkbox" <?php echo $boostMahaMinifyHtml; ?> id="boostMahaMinifyHtml" name="boostMahaMinifyHtml">
							<label for="boostMahaMinifyHtml">Enable/Disable minify html.</label>
						</div>
					</div>
					<div class="boostMahaGroup submit">
						<div class="submit"><input type="submit" value="Submit" class="button-primary"></div>
					</div>
				</form>
				<form method="post" name="removecacheform">
					<input type="hidden" value="1" name="removecache">
					<input type="submit" value="Clear all cached files" class="button-secondary" onclick="return confirm('Are you sure?')">
				</form>
			
			</div>
			<?php
		}

		public function insertToHtaccess( $key ){
			$htaccess_file = ABSPATH.'.htaccess';
			if(is_file( $htaccess_file ) && is_writable( $htaccess_file )){
				$htaccess = file_get_contents($htaccess_file);

				$htaccess = $this->{$key}( $htaccess );
				$htaccess = preg_replace("/\n+/","\n", $htaccess);
				file_put_contents($htaccess_file, $htaccess);
			}
		}

		public function removeFromHtaccess( $key ){
			$htaccess_file = ABSPATH.'.htaccess';
			if(is_file( $htaccess_file ) && is_writable( $htaccess_file )){
				$htaccess = file_get_contents($htaccess_file);

				$preg = "/#\s?BEGIN\s?".$key.".*?#\s?END\s?".$key."/s";
				$htaccess = preg_replace($preg, "", $htaccess);
				file_put_contents($htaccess_file, $htaccess);
			}
		}

		public function htaccess( $data ){
			if ( isset( $data['boostMahaGzip'] ) ) {
				$this->insertToHtaccess( 'boostMahaGzip' );
			} else {
				$this->removeFromHtaccess( 'boostMahaGzip' );
			}

			if ( isset( $data['boostMahaLBC'] ) ) {
				$this->insertToHtaccess( 'boostMahaLBC' );
			} else {
				$this->removeFromHtaccess( 'boostMahaLBC' );
			}
		}

		public function boostMahaGzip( $htaccess ){
			$rules =	"# BEGIN boostMahaGzip"."\n".
						"AddOutputFilterByType DEFLATE application/javascript"."\n".
						"AddOutputFilterByType DEFLATE application/rss+xml"."\n".
						"AddOutputFilterByType DEFLATE application/vnd.ms-fontobject"."\n".
						"AddOutputFilterByType DEFLATE application/x-font"."\n".
						"AddOutputFilterByType DEFLATE application/x-font-opentype"."\n".
						"AddOutputFilterByType DEFLATE application/x-font-otf"."\n".
						"AddOutputFilterByType DEFLATE application/x-font-truetype"."\n".
						"AddOutputFilterByType DEFLATE application/x-font-ttf"."\n".
						"AddOutputFilterByType DEFLATE application/x-javascript"."\n".
						"AddOutputFilterByType DEFLATE application/xhtml+xml"."\n".
						"AddOutputFilterByType DEFLATE application/xml"."\n".
						"AddOutputFilterByType DEFLATE font/opentype"."\n".
						"AddOutputFilterByType DEFLATE font/otf"."\n".
						"AddOutputFilterByType DEFLATE font/ttf"."\n".
						"AddOutputFilterByType DEFLATE image/svg+xml"."\n".
						"AddOutputFilterByType DEFLATE image/x-icon"."\n".
						"AddOutputFilterByType DEFLATE text/css"."\n".
						"AddOutputFilterByType DEFLATE text/html"."\n".
						"AddOutputFilterByType DEFLATE text/javascript"."\n".
						"AddOutputFilterByType DEFLATE text/plain"."\n".
						"AddOutputFilterByType DEFLATE text/xml"."\n".
						"BrowserMatch ^Mozilla/4 gzip-only-text/html"."\n".
						"BrowserMatch ^Mozilla/4\.0[678] no-gzip"."\n".
						"BrowserMatch \bMSIE !no-gzip !gzip-only-text/html"."\n".
						"Header append Vary User-Agent"."\n".
						"# END boostMahaGzip"."\n";
			
			$htaccess = preg_replace("/#\s?BEGIN\s?boostMahaGzip.*?#\s?END\s?boostMahaGzip/s", "", $htaccess);
			return $rules.$htaccess;
		}

		public function boostMahaLBC( $htaccess ){
			$rules =	'# BEGIN boostMahaLBC'."\n".
						'<IfModule mod_expires.c>'."\n".
						'AddType application/vnd.ms-fontobject .eot'."\n".
						'AddType font/ttf .ttf'."\n".
						'AddType font/otf .otf'."\n".
						'AddType application/font-woff .woff'."\n".
						'AddType x-font/otf .otf'."\n".
						'AddType x-font/ttf .ttf'."\n".
						'AddType x-font/eot .eot'."\n".
						'AddType x-font/woff .woff'."\n".
						'AddType x-font/svg .svg'."\n".
						'AddType image/svg+xml .svg'."\n".
						'AddType image/x-icon .ico'."\n".
						'AddType image/png .png'."\n".
						'AddType text/css .css'."\n".
						'ExpiresActive On'."\n".
						'ExpiresByType text/html "access plus 1 month"'."\n".
						'ExpiresByType text/xml "access plus 1 month"'."\n".
						'ExpiresByType application/xml "access plus 1 month"'."\n".
						'ExpiresByType application/json "access plus 1 month"'."\n".
						'ExpiresByType application/rss+xml "access plus 1 hour"'."\n".
						'ExpiresByType application/pdf "access plus 1 month"'."\n".
						'ExpiresByType application/x-shockwave-flash "access plus 1 month"'."\n".
						'ExpiresByType image/x-icon "access plus 1 month"'."\n".
						'ExpiresByType image/jpg "access plus 1 month"'."\n".
						'ExpiresByType image/jpeg "access plus 1 month"'."\n".
						'ExpiresByType image/gif "access plus 1 month"'."\n".
						'ExpiresByType image/png "access plus 1 month"'."\n".
						'ExpiresByType video/ogg "access plus 1 month"'."\n".
						'ExpiresByType audio/ogg "access plus 1 month"'."\n".
						'ExpiresByType video/mp4 "access plus 1 month"'."\n".
						'ExpiresByType video/webm "access plus 1 month"'."\n".
						'ExpiresByType font/truetype "access plus 1 month"'."\n".
						'ExpiresByType font/opentype "access plus 1 month"'."\n".
						'ExpiresByType application/x-font-woff "access plus 1 month"'."\n".
						'ExpiresByType image/svg+xml "access plus 1 month"'."\n".
						'ExpiresByType application/vnd.ms-fontobject "access plus 1 month"'."\n".
						'ExpiresByType text/css "access plus 1 month"'."\n".
						'ExpiresByType text/x-javascript "access plus 1 month"'."\n".
						'ExpiresByType application/javascript "access plus 1 year"'."\n".
						'ExpiresByType text/javascript "access plus 1 year"'."\n".
						'ExpiresDefault "access plus 1 month"'."\n".
						'<IfModule mod_headers.c>'."\n".
						'Header append Cache-Control "public"'."\n".
						'</IfModule>'."\n".
						'</IfModule>'."\n".
						'Header set Expires "access plus 1 month"'."\n".
						'Header set Cache-Control "max-age=2692000, public"'."\n".
  						'Header set Cache-Control "max-age=2692000, private, must-revalidate"'."\n".
						'Header unset ETag'."\n".
						'FileETag None'."\n".
						'# END boostMahaLBC'."\n";

			$htaccess = preg_replace("/#\s?BEGIN\s?boostMahaLBC.*?#\s?END\s?boostMahaLBC/s", "", $htaccess);
			return $rules.$htaccess;
		}


	}
?>